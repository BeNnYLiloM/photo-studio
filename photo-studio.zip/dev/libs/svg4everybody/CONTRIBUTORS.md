# Contributors

You might not have enjoyed SVG for Everybody, had it not been for the effort by these individuals.

- [Adam Ryan Merrifield](https://github.com/AdamMerrifield)
	- The option to cleanup built files from a feature branch
- [Camilo Nova](https://github.com/camilonova)
	- Added bower package
- [Jake Rayson](https://github.com/growdigital)
	- Added npm package
- [Jonathan Neal](https://github.com/jonathantneal)
	- Author and maintainer
- [Luis Merino](https://github.com/Rendez)
	- Overseer of the 2.0 refactor
- [Travis Stone](https://github.com/travstone)
	- The option to validate whether an `<svg>` will be shimmed

<br>

> “Things that are impossible just take longer.”
> — Ian Hickson
